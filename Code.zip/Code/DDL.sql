-- Creating a comprehensive relational database schema for Movies Dataset
create schema movies;
use movies;
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `movies` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `movies` ;

-- -----------------------------------------------------
-- Table `movies`.`Cas`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `movies`.`Cas` (
  `cast_id` VARCHAR(50) NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `gender` CHAR(1) NULL DEFAULT NULL,
  `character_name` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`cast_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `movies`.`Crew`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `movies`.`Crew` (
  `crew_id` VARCHAR(50) NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `gender` CHAR(1) NULL DEFAULT NULL,
  `role` VARCHAR(100) NOT NULL,
  `department` VARCHAR(100) NULL DEFAULT NULL,
  PRIMARY KEY (`crew_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `movies`.`Genres`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `movies`.`Genres` (
  `genre_id` INT NOT NULL,
  `genre_name` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`genre_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `movies`.`Movies`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `movies`.`Movies` (
  `movie_id` VARCHAR(50) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `release_date` DATE NULL DEFAULT NULL,
  `overview` TEXT NULL DEFAULT NULL,
  `budget` BIGINT NULL DEFAULT NULL,
  `revenue` BIGINT NULL DEFAULT NULL,
  `runtime` INT NULL DEFAULT NULL,
  `language` VARCHAR(10) NULL DEFAULT NULL,
  `popularity` FLOAT NULL DEFAULT NULL,
  `vote_average` FLOAT NULL DEFAULT NULL,
  `vote_count` INT NULL DEFAULT NULL,
  PRIMARY KEY (`movie_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `movies`.`MovieCast`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `movies`.`MovieCast` (
  `movie_id` VARCHAR(50) NOT NULL,
  `cast_id` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`movie_id`, `cast_id`),
  INDEX `cast_id` (`cast_id` ASC),
  CONSTRAINT `moviecast_ibfk_1`
    FOREIGN KEY (`movie_id`)
    REFERENCES `movies`.`Movies` (`movie_id`),
  CONSTRAINT `moviecast_ibfk_2`
    FOREIGN KEY (`cast_id`)
    REFERENCES `movies`.`Cas` (`cast_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `movies`.`MovieCrew`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `movies`.`MovieCrew` (
  `movie_id` VARCHAR(50) NOT NULL,
  `crew_id` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`movie_id`, `crew_id`),
  INDEX `crew_id` (`crew_id` ASC),
  CONSTRAINT `moviecrew_ibfk_1`
    FOREIGN KEY (`movie_id`)
    REFERENCES `movies`.`Movies` (`movie_id`),
  CONSTRAINT `moviecrew_ibfk_2`
    FOREIGN KEY (`crew_id`)
    REFERENCES `movies`.`Crew` (`crew_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `movies`.`MovieGenres`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `movies`.`MovieGenres` (
  `movie_id` VARCHAR(50) NOT NULL,
  `genre_id` INT NOT NULL,
  PRIMARY KEY (`movie_id`, `genre_id`),
  INDEX `genre_id` (`genre_id` ASC) VISIBLE,
  CONSTRAINT `moviegenres_ibfk_1`
    FOREIGN KEY (`movie_id`)
    REFERENCES `movies`.`Movies` (`movie_id`),
  CONSTRAINT `moviegenres_ibfk_2`
    FOREIGN KEY (`genre_id`)
    REFERENCES `movies`.`Genres` (`genre_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `movies`.`ProductionCompanies`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `movies`.`ProductionCompanies` (
  `company_id` VARCHAR(50) NOT NULL,
  `company_name` VARCHAR(255) NOT NULL,
  `country` VARCHAR(100) NULL DEFAULT NULL,
  PRIMARY KEY (`company_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `movies`.`MovieProductionCompanies`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `movies`.`MovieProductionCompanies` (
  `movie_id` VARCHAR(50) NOT NULL,
  `company_id` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`movie_id`, `company_id`),
  INDEX `company_id` (`company_id` ASC),
  CONSTRAINT `movieproductioncompanies_ibfk_1`
    FOREIGN KEY (`movie_id`)
    REFERENCES `movies`.`Movies` (`movie_id`),
  CONSTRAINT `movieproductioncompanies_ibfk_2`
    FOREIGN KEY (`company_id`)
    REFERENCES `movies`.`ProductionCompanies` (`company_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `movies`.`Users`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `movies`.`Users` (
  `user_id` VARCHAR(50) NOT NULL,
  `username` VARCHAR(100) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `registration_date` DATE NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `movies`.`UserRatings`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `movies`.`UserRatings` (
  `rating_id` INT NOT NULL AUTO_INCREMENT,
  `user_id` VARCHAR(50) NOT NULL,
  `movie_id` VARCHAR(50) NOT NULL,
  `rating` FLOAT NOT NULL,
  `rating_date` DATE NULL DEFAULT NULL,
  PRIMARY KEY (`rating_id`),
  INDEX `movie_id` (`movie_id` ASC) ,
  INDEX `user_id` (`user_id` ASC) ,
  CONSTRAINT `userratings_ibfk_1`
    FOREIGN KEY (`movie_id`)
    REFERENCES `movies`.`Movies` (`movie_id`),
  CONSTRAINT `userratings_ibfk_2`
    FOREIGN KEY (`user_id`)
    REFERENCES `movies`.`Users` (`user_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
