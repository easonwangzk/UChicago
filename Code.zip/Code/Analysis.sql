# Data Engineering Platform Final Project
# Group 11

# Determine the most popular genres based on the number of movies associated with them:
SELECT 
    g.genre_name, COUNT(mg.movie_id) AS movie_count
FROM
    Genres g
        JOIN
    MovieGenres mg ON g.genre_id = mg.genre_id
GROUP BY g.genre_name
ORDER BY movie_count DESC
LIMIT 5;

# Analyze the performance of production companies based on movie revenue, ratings, and the number of movies produced.
SELECT 
    pc.company_name,
    AVG(m.revenue) AS avg_revenue,
    AVG(ur.rating) AS avg_rating,
    COUNT(m.movie_id) AS movie_count
FROM
    ProductionCompanies pc
        JOIN
    MovieProductionCompanies mpc ON pc.company_id = mpc.company_id
        JOIN
    Movies m ON mpc.movie_id = m.movie_id
        LEFT JOIN
    UserRatings ur ON m.movie_id = ur.movie_id
GROUP BY pc.company_name
ORDER BY avg_revenue DESC , avg_rating DESC
LIMIT 10;

# Analyze the relationship between budget, runtime, genre, and movie revenue to identify the most significant factors.
SELECT DISTINCT
    g.genre_name,
    AVG(m.revenue) AS avg_revenue,
    AVG(m.budget) AS avg_budget,
    AVG(m.runtime) AS avg_runtime
FROM
    Movies m
        JOIN
    MovieGenres mg ON m.movie_id = mg.movie_id
        JOIN
    Genres g ON mg.genre_id = g.genre_id
WHERE
    m.budget > 0 AND m.runtime > 0
GROUP BY g.genre_name
ORDER BY avg_revenue DESC
LIMIT 10;

# Segment users based on their rating patterns and preferences to provide personalized recommendations.
SELECT 
    ur.user_id, g.genre_name, AVG(ur.rating) AS avg_rating
FROM
    UserRatings ur
        JOIN
    Movies m ON ur.movie_id = m.movie_id
        JOIN
    MovieGenres mg ON m.movie_id = mg.movie_id
        JOIN
    Genres g ON mg.genre_id = g.genre_id
GROUP BY ur.user_id , g.genre_name
HAVING AVG(ur.rating) > 4
ORDER BY ur.user_id;

# Analyze the release dates of successful movies to identify patterns that lead to higher box office revenue.
SELECT 
    MONTH(m.release_date) AS release_month,
    COUNT(m.movie_id) AS movie_count,
    AVG(m.revenue) AS avg_revenue
FROM
    Movies m
WHERE
    m.revenue > 0
GROUP BY release_month
ORDER BY release_month;

# Prepare data for building a prediction model to forecast the potential success of a movie based on features like 
# budget, genre, and production company.
SELECT 
    m.budget,
    m.runtime,
    g.genre_name,
    pc.company_name,
    AVG(ur.rating) AS avg_rating,
    m.revenue
FROM
    Movies m
        JOIN
    MovieGenres mg ON m.movie_id = mg.movie_id
        JOIN
    Genres g ON mg.genre_id = g.genre_id
        JOIN
    MovieProductionCompanies mpc ON m.movie_id = mpc.movie_id
        JOIN
    ProductionCompanies pc ON mpc.company_id = pc.company_id
        LEFT JOIN
    UserRatings ur ON m.movie_id = ur.movie_id
GROUP BY m.budget , m.runtime , g.genre_name , pc.company_name , m.revenue;









