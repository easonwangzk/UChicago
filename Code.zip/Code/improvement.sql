ALTER TABLE `movies`.`Movies`
ADD INDEX `idx_release_date` (`release_date`),
ADD INDEX `idx_popularity` (`popularity`);

ALTER TABLE `movies`.`UserRatings`
ADD INDEX `idx_user_movie` (`user_id`, `movie_id`);

